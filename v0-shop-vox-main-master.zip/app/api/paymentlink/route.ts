
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { CASHFREE_CLIENT_ID, CASHFREE_CLIENT_SECRET } = process.env;

  if (!CASHFREE_CLIENT_ID || !CASHFREE_CLIENT_SECRET) {
    return NextResponse.json({ error: "Missing Cashfree keys" }, { status: 500 });
  }

  const order_id = "ORDER_" + Date.now();

  const payload = {
    order_id,
    order_amount: body.totalAmount,
    order_currency: "INR",
    order_note: "Payment for your purchase",
    customer_details: {
      customer_id: body.email,
      customer_email: body.email,
      customer_phone: body.phone,
      customer_name: body.fullName,
    },
    order_meta: {
      return_url: `https://shop.voxindia.co/checkout/success?order_id=${order_id}`,
      notify_url: `https://shop.voxindia.co/api/payment-webhook`,
    },
  };

  try {
    // Step 1: Authenticate
    const authRes = await fetch("https://api.cashfree.com/pg/v1/authenticate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        client_id: CASHFREE_CLIENT_ID,
        client_secret: CASHFREE_CLIENT_SECRET,
      }),
    });

    const authData = await authRes.json();
    const token = authData.data.token;

    if (!token) {
      return NextResponse.json({ error: "Authentication failed" }, { status: 401 });
    }

    // Step 2: Create payment order
    const response = await fetch("https://api.cashfree.com/pg/orders", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-version": "2022-09-01",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(payload),
    });

    const responseData = await response.json();

    if (!response.ok) {
      console.error("Cashfree order error:", responseData);
      return NextResponse.json({ error: responseData.message || "Order creation failed" }, { status: 400 });
    }

    return NextResponse.json(responseData);
  } catch (err) {
    console.error("Cashfree integration error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
